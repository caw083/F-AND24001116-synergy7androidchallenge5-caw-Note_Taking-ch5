package com.example.weatherapi.weathergpsfolder.weatherdata

data class Rain(val `3h`: Double)
