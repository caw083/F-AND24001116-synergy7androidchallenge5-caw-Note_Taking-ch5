package com.example.weatherapi.weathergpsfolder.weatherdata

data class Wind(val speed: Double, val deg: Int, val gust: Double)
