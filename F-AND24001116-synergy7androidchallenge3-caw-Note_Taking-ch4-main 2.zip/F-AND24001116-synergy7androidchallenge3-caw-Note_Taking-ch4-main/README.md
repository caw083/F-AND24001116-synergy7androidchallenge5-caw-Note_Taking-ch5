# F-AND24001116-synergy7androidchallenge4-caw-Note_Taking-ch4
AND2402SYN006 - Christopher Ade Wiyanto
