package com.example.challenge4.fragments.add


class FormDataBinding{
    var TitleText : String = ""
    var ButtonText : String = ""
}